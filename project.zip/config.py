#bot settings

BOT_TOKEN = "6328075751:AAFe3ynMKkiQ2u9wZFT7t6PixjD3viEkwUA"
BOT_OWNER = 6094982119 # for IsOwner filter

# mysql settings

host = "127.0.0.1"
port = 3306
user = "pavel"
password = "pavel"
db_name = "nice"